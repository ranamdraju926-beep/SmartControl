package com.example.smartcontrol

import com.example.smartcontrol.command.Command
import com.example.smartcontrol.command.CommandParser
import com.example.smartcontrol.model.InfoTopic
import com.example.smartcontrol.model.SettingsTarget
import org.junit.Assert.assertEquals
import org.junit.Test

class CommandParserTest {
    private fun p(s: String) = CommandParser.parse(s)

    @Test fun openApp() = assertEquals(Command.OpenApp("youtube"), p("Open YouTube"))
    @Test fun flashlightOn() = assertEquals(Command.Flashlight(true), p("Turn on flashlight"))
    @Test fun flashlightOff() = assertEquals(Command.Flashlight(false), p("turn off the torch"))
    @Test fun volumeUp() = assertEquals(Command.VolumeStep(true), p("Increase volume"))
    @Test fun brightnessSet() = assertEquals(Command.BrightnessSet(50), p("Set brightness to 50%"))
    @Test fun scrollDown() = assertEquals(Command.Scroll(true), p("Scroll down"))
    @Test fun home() = assertEquals(Command.Home, p("Go to home screen"))
    @Test fun battery() = assertEquals(Command.Show(InfoTopic.BATTERY), p("Show battery information"))
    @Test fun internet() = assertEquals(Command.CheckInternet, p("Check internet connection"))
    @Test fun wifiToggleOpensSettings() = assertEquals(Command.OpenSettings(SettingsTarget.WIFI), p("turn on wifi"))
    @Test fun allSettings() = assertEquals(Command.OpenSettings(SettingsTarget.ALL), p("open settings"))
    @Test fun tapCoordinates() = assertEquals(Command.TapAt(540, 1200), p("tap 540 1200"))
    @Test fun stop() = assertEquals(Command.StopAutomation, p("stop automation"))
}
