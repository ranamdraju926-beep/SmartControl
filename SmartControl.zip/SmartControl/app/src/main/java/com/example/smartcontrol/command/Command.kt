package com.example.smartcontrol.command

import com.example.smartcontrol.model.Feature
import com.example.smartcontrol.model.InfoTopic
import com.example.smartcontrol.model.SettingsTarget

sealed interface Command {
    data class OpenApp(val name: String) : Command
    data object Home : Command
    data object Back : Command
    data object Recents : Command
    data object SwitchApp : Command
    data object QuickSettingsPanel : Command
    data object Notifications : Command
    data class Flashlight(val on: Boolean?) : Command
    data class VolumeStep(val up: Boolean) : Command
    data class VolumeSet(val percent: Int) : Command
    data class Mute(val mute: Boolean) : Command
    data class BrightnessStep(val up: Boolean) : Command
    data class BrightnessSet(val percent: Int) : Command
    data class Scroll(val down: Boolean) : Command
    data class Swipe(val left: Boolean) : Command
    data class TapText(val label: String) : Command
    data class TapAt(val x: Int, val y: Int) : Command
    data class LongPressAt(val x: Int, val y: Int) : Command
    data class OpenSettings(val target: SettingsTarget) : Command
    data class Show(val topic: InfoTopic) : Command
    data object CheckInternet : Command
    data object StopAutomation : Command
    data class Unknown(val text: String) : Command
}

/** Which user-switchable feature a command belongs to (null = always allowed). */
val Command.feature: Feature?
    get() = when (this) {
        is Command.OpenApp -> Feature.APPS
        Command.Home, Command.Back, Command.Recents, Command.SwitchApp,
        Command.QuickSettingsPanel, Command.Notifications -> Feature.NAVIGATION
        is Command.Scroll, is Command.Swipe, is Command.TapText,
        is Command.TapAt, is Command.LongPressAt -> Feature.GESTURES
        is Command.OpenSettings -> Feature.SETTINGS_SHORTCUTS
        is Command.Flashlight -> Feature.FLASHLIGHT
        is Command.VolumeStep, is Command.VolumeSet, is Command.Mute -> Feature.VOLUME
        is Command.BrightnessStep, is Command.BrightnessSet -> Feature.BRIGHTNESS
        else -> null
    }

/** Rule-based natural-language parser. Works offline; swap in an LLM later by producing the same Commands. */
object CommandParser {

    private val fillers = Regex("^(hey assistant|ok assistant|please|can you|could you|would you|kindly|just)\\s+")
    private val number = Regex("(\\d{1,3})\\s*(%|percent)?")
    private val radioTargets = setOf(
        SettingsTarget.WIFI, SettingsTarget.BLUETOOTH, SettingsTarget.AIRPLANE,
        SettingsTarget.HOTSPOT, SettingsTarget.NFC, SettingsTarget.LOCATION
    )
    private val aliasList = SettingsTarget.entries
        .filter { it != SettingsTarget.ALL }
        .flatMap { t -> t.aliases.map { it to t } }
        .sortedByDescending { it.first.length }

    private fun String.has(vararg words: String) =
        words.any { Regex("\\b${Regex.escape(it)}\\b").containsMatchIn(this) }

    fun parse(raw: String): Command {
        var t = raw.lowercase().trim().trimEnd('.', '!', '?')
        while (true) {
            val next = fillers.replace(t, "")
            if (next == t) break
            t = next
        }
        if (t.isEmpty()) return Command.Unknown(raw)

        if (t.has("stop automation", "cancel automation", "emergency stop") || t == "stop") {
            return Command.StopAutomation
        }
        if (t.has("quick settings")) return Command.QuickSettingsPanel
        if (t.has("notification panel", "notification shade") ||
            Regex("^(open|show|pull down)( the)? notifications$").matches(t)
        ) return Command.Notifications

        settingsTarget(t)?.let { return Command.OpenSettings(it) }

        if (t.has("flashlight", "flash light", "torch")) {
            return Command.Flashlight(
                when {
                    t.has("off", "disable", "stop") -> false
                    t.has("on", "enable", "start") -> true
                    else -> null
                }
            )
        }

        if (t.has("unmute")) return Command.Mute(false)
        if (t.has("mute")) return Command.Mute(true)

        if (t.has("volume", "louder", "quieter", "softer")) {
            number.find(t)?.groupValues?.get(1)?.toIntOrNull()?.let {
                return Command.VolumeSet(it.coerceIn(0, 100))
            }
            if (t.has("up", "increase", "raise", "louder", "higher", "more")) return Command.VolumeStep(true)
            if (t.has("down", "decrease", "lower", "reduce", "quieter", "softer", "less")) return Command.VolumeStep(false)
        }

        if (t.has("brightness", "brighter", "dimmer", "dim")) {
            number.find(t)?.groupValues?.get(1)?.toIntOrNull()?.let {
                return Command.BrightnessSet(it.coerceIn(1, 100))
            }
            if (t.has("up", "increase", "raise", "brighter", "higher", "more")) return Command.BrightnessStep(true)
            if (t.has("down", "decrease", "lower", "reduce", "dimmer", "dim", "less")) return Command.BrightnessStep(false)
        }

        if (Regex("^(go |return |back )?(to )?(the )?home( screen)?$").matches(t) || t.has("home screen", "go home")) {
            return Command.Home
        }
        if (Regex("^(go )?back$|^navigate back$").matches(t)) return Command.Back
        if (t.has("recent apps", "recents", "overview", "app switcher")) return Command.Recents
        if (t.has("switch app", "switch apps", "previous app", "last app", "switch to previous")) {
            return Command.SwitchApp
        }

        Regex("scroll\\s+(up|down)").find(t)?.let { return Command.Scroll(it.groupValues[1] == "down") }
        Regex("swipe\\s+(left|right)").find(t)?.let { return Command.Swipe(it.groupValues[1] == "left") }

        Regex("^long[ -]?press\\s+(?:at\\s+)?(\\d+)\\s*[, ]\\s*(\\d+)$").find(t)?.let {
            return Command.LongPressAt(it.groupValues[1].toInt(), it.groupValues[2].toInt())
        }
        Regex("^(?:tap|click|press|touch)\\s+(?:at\\s+)?(\\d+)\\s*[, ]\\s*(\\d+)$").find(t)?.let {
            return Command.TapAt(it.groupValues[1].toInt(), it.groupValues[2].toInt())
        }
        Regex("^(?:tap|click|press|touch|select)\\s+(?:on\\s+)?(?:the\\s+)?(.+)$").find(t)?.let {
            return Command.TapText(it.groupValues[1].trim())
        }

        Regex("^(?:open|launch|start|run)\\s+(?:the\\s+)?(?:app\\s+)?(.+)$").find(t)?.let {
            return Command.OpenApp(it.groupValues[1].trim())
        }

        if (t.has("internet", "online", "connected")) return Command.CheckInternet
        if (t.has("battery")) return Command.Show(InfoTopic.BATTERY)
        if (t.has("storage", "disk space", "free space")) return Command.Show(InfoTopic.STORAGE)
        if (t.has("wifi", "wi-fi", "mobile network", "network", "signal")) return Command.Show(InfoTopic.NETWORK)
        if (t.has("device info", "device information", "phone info", "phone information",
                "about phone", "ram", "memory", "android version", "model")
        ) return Command.Show(InfoTopic.DEVICE)

        return Command.Unknown(raw)
    }

    private fun settingsTarget(t: String): SettingsTarget? {
        val toggleVerb = Regex("^(turn|switch|toggle|enable|disable|set)\\b").containsMatchIn(t)
        if (toggleVerb) {
            aliasList.firstOrNull { it.second in radioTargets && t.has(it.first) }?.let { return it.second }
        }
        if (t.has("settings", "setting")) {
            aliasList.firstOrNull { t.has(it.first) }?.let { return it.second }
            if (Regex("^(open |go to |launch |show )?(the )?(android |system |phone )?settings( app)?$").matches(t)) {
                return SettingsTarget.ALL
            }
            return null
        }
        val name = Regex("^(?:open|go to|launch|show)\\s+(?:the\\s+)?(.+)$").find(t)?.groupValues?.get(1)
        return aliasList.firstOrNull { it.first == name }?.second
    }
}
