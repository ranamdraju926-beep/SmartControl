package com.example.smartcontrol.ui

import android.content.ActivityNotFoundException
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Dashboard
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.PhoneAndroid
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.repeatOnLifecycle
import com.example.smartcontrol.model.ActionResult
import com.example.smartcontrol.model.PermissionKind
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {

    private val vm: MainViewModel by viewModels()

    // System speech UI: no RECORD_AUDIO permission needed because Google's recognizer owns the mic.
    private val speech = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val heard = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (r.resultCode == RESULT_OK && !heard.isNullOrBlank()) vm.submit(heard)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { SmartTheme { AppRoot(vm, onMic = ::startVoice) } }
    }

    private fun startVoice() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_PROMPT, "Say a command")
        try {
            speech.launch(intent)
        } catch (e: ActivityNotFoundException) {
            vm.post(ActionResult.Failure("No speech recognition service is installed on this device."))
        }
    }
}

@Composable
fun AppRoot(vm: MainViewModel, onMic: () -> Unit) {
    val s by vm.state.collectAsStateWithLifecycle()
    val owner = LocalLifecycleOwner.current
    LaunchedEffect(owner) {
        owner.lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
            while (true) {
                vm.refresh()
                delay(2000)
            }
        }
    }
    var tab by rememberSaveable { mutableIntStateOf(0) }

    AuroraBackground {
        Scaffold(
            containerColor = Color.Transparent,
            topBar = { Header(s, vm) },
            bottomBar = {
                Column {
                    CommandBar(heard = s.heard, onSubmit = vm::submit, onMic = onMic)
                    NavigationBar(containerColor = Ink.copy(alpha = 0.8f)) {
                        val items = listOf(
                            Triple("Control", Icons.Rounded.PhoneAndroid, 0),
                            Triple("Automate", Icons.Rounded.Bolt, 1),
                            Triple("Device", Icons.Rounded.Dashboard, 2),
                            Triple("Access", Icons.Rounded.Shield, 3)
                        )
                        items.forEach { (label, icon, index) ->
                            NavigationBarItem(
                                selected = tab == index, onClick = { tab = index },
                                icon = { Icon(icon, label) },
                                label = { Text(label, fontSize = 11.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Ink, selectedTextColor = Cyan,
                                    indicatorColor = Cyan, unselectedIconColor = TextLo, unselectedTextColor = TextLo
                                )
                            )
                        }
                    }
                }
            }
        ) { padding ->
            Box(Modifier.padding(padding)) {
                Crossfade(tab, animationSpec = tween(220), label = "tab") { t ->
                    when (t) {
                        0 -> ControlTab(s, vm)
                        1 -> AutomateTab(s, vm)
                        2 -> DeviceTab(s)
                        else -> AccessTab(s, vm)
                    }
                }
            }
        }
    }
}

@Composable
private fun Header(s: UiState, vm: MainViewModel) {
    Column(Modifier.statusBarsPadding().padding(horizontal = 16.dp, vertical = 10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Smart Control", color = TextHi, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.size(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatusChip(
                        if (s.perms.accessibility) "Accessibility on" else "Accessibility off",
                        if (s.perms.accessibility) Ok else Warn
                    )
                    if (s.running) StatusChip("Running", Cyan)
                }
            }
            StopButton(running = s.running, onClick = vm::stopAll)
        }
        ResultBanner(s.result, onGrant = vm::grant, onDismiss = vm::dismissResult)
    }
}

@Composable
private fun StopButton(running: Boolean, onClick: () -> Unit) {
    val pulse = rememberInfiniteTransition(label = "stop")
    val alpha by pulse.animateFloat(
        initialValue = 1f, targetValue = if (running) 0.55f else 1f,
        animationSpec = infiniteRepeatable(tween(650), RepeatMode.Reverse), label = "alpha"
    )
    val shape = RoundedCornerShape(18.dp)
    Row(
        Modifier
            .graphicsLayer { this.alpha = alpha }
            .background(Danger.copy(alpha = if (running) 0.9f else 0.16f), shape)
            .border(1.dp, Danger, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Rounded.Stop, null, tint = if (running) Color.White else Danger, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(6.dp))
        Text("Stop", color = if (running) Color.White else Danger, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
    }
}

@Composable
private fun ResultBanner(result: ActionResult?, onGrant: (PermissionKind) -> Unit, onDismiss: () -> Unit) {
    var last by remember { mutableStateOf<ActionResult?>(null) }
    if (result != null) last = result
    AnimatedVisibility(
        visible = result != null,
        enter = slideInVertically { -it / 2 } + fadeIn(),
        exit = slideOutVertically { -it / 2 } + fadeOut()
    ) {
        val r = last ?: return@AnimatedVisibility
        val color = when (r) {
            is ActionResult.Success -> Ok
            is ActionResult.NeedsPermission -> Warn
            is ActionResult.Failure -> Danger
        }
        val shape = RoundedCornerShape(18.dp)
        Row(
            Modifier
                .padding(top = 10.dp)
                .fillMaxWidth()
                .background(color.copy(alpha = 0.13f), shape)
                .border(1.dp, color.copy(alpha = 0.45f), shape)
                .clickable(onClick = onDismiss)
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(r.message, color = color, fontSize = 13.sp, modifier = Modifier.weight(1f))
            if (r is ActionResult.NeedsPermission) {
                Text(
                    "Grant", color = color, fontWeight = FontWeight.Bold, fontSize = 13.sp,
                    modifier = Modifier.padding(start = 12.dp).clickable { onGrant(r.permission) }
                )
            }
        }
    }
}

@Composable
private fun CommandBar(heard: String?, onSubmit: (String) -> Unit, onMic: () -> Unit) {
    var text by rememberSaveable { mutableStateOf("") }
    fun send() {
        if (text.isNotBlank()) {
            onSubmit(text)
            text = ""
        }
    }
    Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
        heard?.let {
            Text("You said: “$it”", color = TextLo, fontSize = 12.sp, modifier = Modifier.padding(start = 8.dp, bottom = 6.dp))
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = text, onValueChange = { text = it }, singleLine = true,
                placeholder = { Text("Try “open YouTube”") },
                shape = RoundedCornerShape(28.dp), colors = glassFieldColors(),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { send() }),
                trailingIcon = {
                    IconButton(onClick = ::send) { Icon(Icons.AutoMirrored.Rounded.Send, "Send command", tint = Cyan) }
                },
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(10.dp))
            MicButton(onMic)
        }
    }
}

@Composable
private fun MicButton(onClick: () -> Unit) {
    val t = rememberInfiniteTransition(label = "mic")
    val ring by t.animateFloat(
        initialValue = 1f, targetValue = 1.28f,
        animationSpec = infiniteRepeatable(tween(1600), RepeatMode.Reverse), label = "ring"
    )
    Box(contentAlignment = Alignment.Center) {
        Box(
            Modifier
                .size(56.dp)
                .graphicsLayer { scaleX = ring; scaleY = ring; alpha = 0.35f }
                .background(Brush.linearGradient(listOf(Cyan, Violet)), CircleShape)
        )
        Box(
            Modifier
                .size(56.dp)
                .background(Brush.linearGradient(listOf(Cyan, Violet)), CircleShape)
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Rounded.Mic, "Voice command", tint = Ink, modifier = Modifier.size(26.dp)) }
    }
}
