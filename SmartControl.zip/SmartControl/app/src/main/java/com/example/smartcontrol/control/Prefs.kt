package com.example.smartcontrol.control

import android.content.Context
import com.example.smartcontrol.model.Feature
import com.example.smartcontrol.model.Step
import com.example.smartcontrol.model.StepType
import org.json.JSONArray
import org.json.JSONObject

/** Stores per-feature switches and the saved automation sequence. Nothing else is persisted. */
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("smart_control", Context.MODE_PRIVATE)

    fun isEnabled(f: Feature): Boolean = sp.getBoolean("feature_${f.name}", true)
    fun setEnabled(f: Feature, enabled: Boolean) =
        sp.edit().putBoolean("feature_${f.name}", enabled).apply()

    fun loadSteps(): List<Step> = runCatching {
        val arr = JSONArray(sp.getString("steps", "[]"))
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Step(StepType.valueOf(o.getString("t")), o.optInt("x"), o.optInt("y"), o.optLong("w", 1000))
        }
    }.getOrDefault(emptyList())

    fun saveSteps(steps: List<Step>) {
        val arr = JSONArray()
        steps.forEach {
            arr.put(JSONObject().put("t", it.type.name).put("x", it.x).put("y", it.y).put("w", it.waitMs))
        }
        sp.edit().putString("steps", arr.toString()).apply()
    }
}
