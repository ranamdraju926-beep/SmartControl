package com.example.smartcontrol.model

import android.media.AudioManager

/** Every action returns one of these. Nothing reports success unless Android accepted it. */
sealed interface ActionResult {
    val message: String

    data class Success(override val message: String) : ActionResult
    data class NeedsPermission(override val message: String, val permission: PermissionKind) : ActionResult
    data class Failure(override val message: String) : ActionResult
}

enum class PermissionKind(val title: String, val why: String) {
    ACCESSIBILITY(
        "Accessibility service",
        "Taps, swipes, scrolling, Back/Home/Recents and Quick Settings."
    ),
    WRITE_SETTINGS("Modify system settings", "Changing screen brightness."),
    DND_ACCESS("Do Not Disturb access", "Muting the ringer on some devices.")
}

enum class Feature(val label: String, val hint: String) {
    APPS("App launching", "Open installed apps"),
    NAVIGATION("System navigation", "Home, Back, Recents, panels"),
    GESTURES("Screen gestures", "Tap, scroll, swipe, long press"),
    SETTINGS_SHORTCUTS("Settings shortcuts", "Wi-Fi, Bluetooth, display and more"),
    FLASHLIGHT("Flashlight", "Torch on and off"),
    VOLUME("Volume", "Volume and mute"),
    BRIGHTNESS("Brightness", "Screen brightness")
}

enum class SettingsTarget(val label: String, val aliases: List<String>) {
    WIFI("Wi-Fi", listOf("wifi", "wi-fi", "wi fi")),
    BLUETOOTH("Bluetooth", listOf("bluetooth")),
    AIRPLANE("Airplane mode", listOf("airplane mode", "airplane", "flight mode")),
    HOTSPOT("Hotspot", listOf("hotspot", "tethering")),
    DISPLAY("Display", listOf("display")),
    SOUND("Sound", listOf("sound", "audio")),
    LOCATION("Location", listOf("location", "gps")),
    NFC("NFC", listOf("nfc")),
    BATTERY_SAVER("Battery saver", listOf("battery saver", "power saving")),
    STORAGE("Storage", listOf("storage")),
    ALL("All settings", listOf("settings"))
}

enum class InfoTopic { BATTERY, STORAGE, NETWORK, DEVICE }

enum class StreamKind(val label: String, val id: Int) {
    MEDIA("Media", AudioManager.STREAM_MUSIC),
    RING("Ring", AudioManager.STREAM_RING),
    ALARM("Alarm", AudioManager.STREAM_ALARM)
}

enum class StepType(val label: String) {
    TAP("Tap"), LONG_PRESS("Long press"),
    SCROLL_UP("Scroll up"), SCROLL_DOWN("Scroll down"),
    SWIPE_LEFT("Swipe left"), SWIPE_RIGHT("Swipe right"),
    BACK("Back"), HOME("Home"), RECENTS("Recents"), WAIT("Wait")
}

data class Step(
    val type: StepType,
    val x: Int = 0,
    val y: Int = 0,
    val waitMs: Long = 1000
) {
    fun describe(): String = when (type) {
        StepType.TAP, StepType.LONG_PRESS -> "${type.label} ($x, $y)"
        StepType.WAIT -> "Wait ${waitMs / 1000.0} s"
        else -> type.label
    }
}

data class LaunchableApp(val label: String, val packageName: String)
data class VolumeState(val percent: Int, val muted: Boolean)

data class BatteryInfo(
    val percent: Int,
    val charging: Boolean,
    val statusLabel: String,
    val source: String?,
    val temperatureC: Float?,
    val healthLabel: String
)

data class StorageInfo(val totalBytes: Long, val usedBytes: Long, val freeBytes: Long) {
    val usedFraction: Float
        get() = if (totalBytes == 0L) 0f else usedBytes.toFloat() / totalBytes
}

data class NetSnapshot(
    val connected: Boolean,
    val internetVerified: Boolean,
    val transport: String,
    val wifiEnabled: Boolean,
    val cellularActive: Boolean,
    val cellularGeneration: String?,
    val metered: Boolean
)

data class DeviceInfo(
    val brand: String,
    val model: String,
    val androidVersion: String,
    val sdk: Int,
    val securityPatch: String?,
    val totalRamBytes: Long,
    val availRamBytes: Long
) {
    val ramUsedFraction: Float
        get() = if (totalRamBytes == 0L) 0f else 1f - availRamBytes.toFloat() / totalRamBytes
}

fun Long.gb(): String = "%.1f GB".format(this / 1_000_000_000.0)

fun BatteryInfo.summary(): String = buildString {
    append("Battery $percent% · $statusLabel")
    source?.let { append(" ($it)") }
    append("\nTemperature: ")
    append(temperatureC?.let { "%.1f °C".format(it) } ?: "not reported by this device")
    append("\nHealth: $healthLabel")
}

fun StorageInfo.summary(): String =
    "Storage: ${usedBytes.gb()} used of ${totalBytes.gb()} · ${freeBytes.gb()} available"

fun NetSnapshot.summary(): String = buildString {
    append("Connection: ${if (connected) transport else "none"}")
    cellularGeneration?.let { append(" ($it)") }
    append("\nWi-Fi radio: ${if (wifiEnabled) "on" else "off"}")
    append("\nMobile network: ${if (cellularActive) "active connection" else "not the active connection"}")
    if (connected) append("\nInternet: ${if (internetVerified) "verified by Android" else "not verified"}")
}

fun DeviceInfo.summary(): String =
    "$brand $model · Android $androidVersion (API $sdk)\n" +
        "RAM: ${availRamBytes.gb()} free of ${totalRamBytes.gb()}"
