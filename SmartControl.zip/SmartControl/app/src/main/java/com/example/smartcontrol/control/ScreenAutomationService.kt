package com.example.smartcontrol.control

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/**
 * Process-wide hook so the service can stop automation even when the app UI is not in front.
 * The ViewModel registers its stop handler here.
 */
object EmergencyStop {
    @Volatile var handler: (() -> Unit)? = null
    fun trigger() { handler?.invoke() }
}

/**
 * User-enabled accessibility service. It never reads or stores screen content on its own:
 * it only performs gestures/global actions that the user requested, plus an optional
 * "tap by label" lookup that runs once per explicit command.
 *
 * Emergency stop: holding Volume Up + Volume Down together stops any running automation.
 */
class ScreenAutomationService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: ScreenAutomationService? = null
            private set
    }

    private var volUp = false
    private var volDown = false

    override fun onServiceConnected() {
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() = Unit

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val down = event.action == KeyEvent.ACTION_DOWN
        when (event.keyCode) {
            KeyEvent.KEYCODE_VOLUME_UP -> volUp = down
            KeyEvent.KEYCODE_VOLUME_DOWN -> volDown = down
        }
        if (down && volUp && volDown) EmergencyStop.trigger()
        return false // never swallow the volume keys
    }

    // ───────────── Public actions (all return what Android actually reported) ─────────────

    fun screenSize(): Pair<Int, Int> =
        resources.displayMetrics.let { it.widthPixels to it.heightPixels }

    fun global(action: Int): Boolean = performGlobalAction(action)

    suspend fun tap(x: Float, y: Float): Boolean =
        stroke(Path().apply { moveTo(x, y) }, 60)

    suspend fun longPress(x: Float, y: Float, durationMs: Long = 800): Boolean =
        stroke(Path().apply { moveTo(x, y) }, durationMs)

    suspend fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long = 350): Boolean =
        stroke(Path().apply { moveTo(x1, y1); lineTo(x2, y2) }, durationMs)

    /** "Scroll down" = content moves up, so the finger travels upward. */
    suspend fun scroll(down: Boolean): Boolean {
        val (w, h) = screenSize()
        val x = w / 2f
        return if (down) swipe(x, h * 0.72f, x, h * 0.28f, 400)
        else swipe(x, h * 0.28f, x, h * 0.72f, 400)
    }

    /** "Swipe left" = finger travels from right to left. */
    suspend fun swipeHorizontal(left: Boolean): Boolean {
        val (w, h) = screenSize()
        val y = h / 2f
        return if (left) swipe(w * 0.8f, y, w * 0.2f, y, 300)
        else swipe(w * 0.2f, y, w * 0.8f, y, 300)
    }

    /** Clicks the first clickable node whose text or description matches [label]. */
    fun clickByLabel(label: String): Boolean {
        val root = rootInActiveWindow ?: return false
        return try {
            root.findAccessibilityNodeInfosByText(label).any { node ->
                var cur: AccessibilityNodeInfo? = node
                while (cur != null && !cur.isClickable) cur = cur.parent
                cur?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true
            }
        } finally {
            root.recycle()
        }
    }

    private suspend fun stroke(path: Path, durationMs: Long): Boolean =
        suspendCancellableCoroutine { cont ->
            val gesture = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs))
                .build()
            val accepted = dispatchGesture(gesture, object : GestureResultCallback() {
                override fun onCompleted(g: GestureDescription?) {
                    if (cont.isActive) cont.resume(true)
                }

                override fun onCancelled(g: GestureDescription?) {
                    if (cont.isActive) cont.resume(false)
                }
            }, null)
            if (!accepted && cont.isActive) cont.resume(false)
        }
}
