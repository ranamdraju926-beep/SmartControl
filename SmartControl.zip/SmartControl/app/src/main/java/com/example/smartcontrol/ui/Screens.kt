@file:OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package com.example.smartcontrol.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.smartcontrol.command.Command
import com.example.smartcontrol.model.*

private fun UiState.noteFor(f: Feature, needsAccessibility: Boolean = false): String? = when {
    toggles[f] == false -> "Turned off"
    needsAccessibility && !perms.accessibility -> "Needs access"
    else -> null
}

private val pagePadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 24.dp)

// ═════════════════════════════════ CONTROL ═════════════════════════════════

@Composable
fun ControlTab(s: UiState, vm: MainViewModel) {
    LaunchedEffect(Unit) { vm.loadApps() }
    LazyColumn(contentPadding = pagePadding, verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { NavigationCard(s, vm) }
        item { FlashlightCard(s, vm) }
        item { VolumeCard(s, vm) }
        item { BrightnessCard(s, vm) }
        item { AppsCard(s, vm) }
        item { ShortcutsCard(s, vm) }
    }
}

private data class Tile(val icon: ImageVector, val label: String, val command: Command)

@Composable
private fun NavigationCard(s: UiState, vm: MainViewModel) {
    val tiles = listOf(
        Tile(Icons.Rounded.Home, "Home", Command.Home),
        Tile(Icons.AutoMirrored.Rounded.ArrowBack, "Back", Command.Back),
        Tile(Icons.Rounded.ViewCarousel, "Recents", Command.Recents),
        Tile(Icons.Rounded.SwapHoriz, "Last app", Command.SwitchApp),
        Tile(Icons.Rounded.Tune, "Quick Settings", Command.QuickSettingsPanel),
        Tile(Icons.Rounded.Notifications, "Notifications", Command.Notifications)
    )
    Section("System navigation", "Works through the accessibility service") {
        tiles.chunked(3).forEach { row ->
            Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { t ->
                    ActionTile(
                        t.icon, t.label, Modifier.weight(1f),
                        note = s.noteFor(Feature.NAVIGATION, needsAccessibility = true)
                    ) { vm.run(t.command) }
                }
            }
        }
    }
}

@Composable
private fun FlashlightCard(s: UiState, vm: MainViewModel) {
    Section("Flashlight", if (!s.hasFlash) "No camera flash on this device" else "Live status from the camera system") {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                if (s.torchOn) Icons.Rounded.FlashlightOn else Icons.Rounded.FlashlightOff, null,
                tint = if (s.torchOn) Warn else TextLo, modifier = Modifier.size(34.dp)
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(if (s.torchOn) "On" else "Off", color = TextHi, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                if (s.toggles[Feature.FLASHLIGHT] == false) Text("Turned off in Access", color = Warn, fontSize = 12.sp)
            }
            Switch(
                checked = s.torchOn,
                onCheckedChange = { if (s.toggles[Feature.FLASHLIGHT] == false) vm.run(Command.Flashlight(it)) else vm.setFlashlight(it) },
                enabled = s.hasFlash,
                colors = glassSwitchColors()
            )
        }
    }
}

@Composable
private fun VolumeCard(s: UiState, vm: MainViewModel) {
    Section("Volume", "Each slider controls one Android audio stream") {
        if (s.toggles[Feature.VOLUME] == false) {
            Text("Volume control is turned off in Access.", color = Warn, fontSize = 13.sp)
            return@Section
        }
        StreamKind.entries.forEach { k ->
            val v = s.volumes[k] ?: return@forEach
            var drag by remember(k, v.percent) { mutableFloatStateOf(v.percent.toFloat()) }
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { vm.toggleMute(k) }) {
                    Icon(
                        if (v.muted || v.percent == 0) Icons.Rounded.VolumeOff else Icons.Rounded.VolumeUp, null,
                        tint = if (v.muted) Warn else Cyan
                    )
                }
                Column(Modifier.weight(1f)) {
                    Text(k.label + if (v.muted) " · muted" else "", color = TextLo, fontSize = 12.sp)
                    Slider(
                        value = drag, onValueChange = { drag = it },
                        onValueChangeFinished = { vm.setVolume(k, drag.toInt()) },
                        valueRange = 0f..100f, colors = glassSliderColors()
                    )
                }
                Text("${drag.toInt()}%", color = TextHi, fontSize = 13.sp, modifier = Modifier.width(44.dp), textAlign = TextAlign.End)
            }
        }
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            SoftButton("Down", Modifier.weight(1f), Icons.Rounded.VolumeDown) { vm.run(Command.VolumeStep(false)) }
            SoftButton("Up", Modifier.weight(1f), Icons.Rounded.VolumeUp) { vm.run(Command.VolumeStep(true)) }
        }
    }
}

@Composable
private fun BrightnessCard(s: UiState, vm: MainViewModel) {
    Section("Brightness", "Setting it manually turns off adaptive brightness") {
        if (!s.perms.writeSettings) {
            PermissionHint("Needs “Modify system settings”.", "Grant") { vm.grant(PermissionKind.WRITE_SETTINGS) }
            Spacer(Modifier.height(8.dp))
        }
        val b = s.brightness
        if (b == null) {
            Text("Brightness can't be read on this device.", color = TextLo, fontSize = 13.sp)
            return@Section
        }
        var drag by remember(b) { mutableFloatStateOf(b.toFloat()) }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.BrightnessLow, null, tint = TextLo)
            Slider(
                value = drag, onValueChange = { drag = it },
                onValueChangeFinished = { vm.setBrightness(drag.toInt()) },
                valueRange = 1f..100f, enabled = s.perms.writeSettings,
                colors = glassSliderColors(), modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
            )
            Icon(Icons.Rounded.BrightnessHigh, null, tint = TextLo)
            Text("${drag.toInt()}%", color = TextHi, fontSize = 13.sp, modifier = Modifier.width(44.dp), textAlign = TextAlign.End)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            SoftButton("Dimmer", Modifier.weight(1f), Icons.Rounded.BrightnessLow) { vm.run(Command.BrightnessStep(false)) }
            SoftButton("Brighter", Modifier.weight(1f), Icons.Rounded.BrightnessHigh) { vm.run(Command.BrightnessStep(true)) }
        }
    }
}

@Composable
private fun AppsCard(s: UiState, vm: MainViewModel) {
    var query by rememberSaveable { mutableStateOf("") }
    val matches = remember(query, s.apps) {
        if (query.isBlank()) emptyList() else s.apps.filter { it.label.contains(query, ignoreCase = true) }.take(5)
    }
    Section("Open an app", "${s.apps.size} launchable apps found on this device") {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = query, onValueChange = { query = it }, singleLine = true,
                placeholder = { Text("Search apps") },
                leadingIcon = { Icon(Icons.Rounded.Search, null, tint = TextLo) },
                shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp),
                colors = glassFieldColors(), modifier = Modifier.weight(1f)
            )
        }
        matches.forEach { app ->
            Row(
                Modifier.fillMaxWidth().clickable { vm.openPackage(app) }.padding(vertical = 12.dp, horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Rounded.Apps, null, tint = Cyan)
                Spacer(Modifier.width(12.dp))
                Text(app.label, color = TextHi, fontSize = 15.sp, modifier = Modifier.weight(1f))
                Text("Open", color = Cyan, fontSize = 13.sp)
            }
        }
        if (query.isNotBlank() && matches.isEmpty()) {
            Text("No installed app matches “$query”.", color = TextLo, fontSize = 13.sp, modifier = Modifier.padding(top = 10.dp))
        }
    }
}

private fun SettingsTarget.icon(): ImageVector = when (this) {
    SettingsTarget.WIFI -> Icons.Rounded.Wifi
    SettingsTarget.BLUETOOTH -> Icons.Rounded.Bluetooth
    SettingsTarget.AIRPLANE -> Icons.Rounded.AirplanemodeActive
    SettingsTarget.HOTSPOT -> Icons.Rounded.WifiTethering
    SettingsTarget.DISPLAY -> Icons.Rounded.Smartphone
    SettingsTarget.SOUND -> Icons.Rounded.VolumeUp
    SettingsTarget.LOCATION -> Icons.Rounded.LocationOn
    SettingsTarget.NFC -> Icons.Rounded.Nfc
    SettingsTarget.BATTERY_SAVER -> Icons.Rounded.BatterySaver
    SettingsTarget.STORAGE -> Icons.Rounded.Storage
    SettingsTarget.ALL -> Icons.Rounded.Settings
}

@Composable
private fun ShortcutsCard(s: UiState, vm: MainViewModel) {
    Section(
        "Settings shortcuts",
        if (s.toggles[Feature.SETTINGS_SHORTCUTS] == false) "Turned off in Access"
        else "Android doesn't let apps flip Wi-Fi or Bluetooth directly, so these open the system screen"
    ) {
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            SettingsTarget.entries.forEach { t -> GlassChip(t.label, t.icon()) { vm.openSettings(t) } }
        }
    }
}

// ═════════════════════════════════ AUTOMATE ═════════════════════════════════

@Composable
fun AutomateTab(s: UiState, vm: MainViewModel) {
    var x by rememberSaveable { mutableStateOf("") }
    var y by rememberSaveable { mutableStateOf("") }
    var label by rememberSaveable { mutableStateOf("") }

    fun coords(): Pair<Int, Int>? {
        val px = x.toIntOrNull()
        val py = y.toIntOrNull()
        if (px == null || py == null) {
            vm.post(ActionResult.Failure("Enter X and Y in pixels first."))
            return null
        }
        return px to py
    }

    LazyColumn(contentPadding = pagePadding, verticalArrangement = Arrangement.spacedBy(14.dp)) {
        if (!s.perms.accessibility) item {
            PermissionHint("Gestures need the accessibility service.", "Enable") { vm.grant(PermissionKind.ACCESSIBILITY) }
        }
        item {
            Section("Scroll & swipe", "Acts on whichever app is in front") {
                Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    val n = s.noteFor(Feature.GESTURES, needsAccessibility = true)
                    ActionTile(Icons.Rounded.KeyboardArrowUp, "Scroll up", Modifier.weight(1f), n) { vm.run(Command.Scroll(false)) }
                    ActionTile(Icons.Rounded.KeyboardArrowDown, "Scroll down", Modifier.weight(1f), n) { vm.run(Command.Scroll(true)) }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    val n = s.noteFor(Feature.GESTURES, needsAccessibility = true)
                    ActionTile(Icons.AutoMirrored.Rounded.ArrowBack, "Swipe left", Modifier.weight(1f), n) { vm.run(Command.Swipe(true)) }
                    ActionTile(Icons.AutoMirrored.Rounded.ArrowForward, "Swipe right", Modifier.weight(1f), n) { vm.run(Command.Swipe(false)) }
                }
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("3-second delay", color = TextHi, fontSize = 14.sp)
                        Text("Time to switch to the app you want to control", color = TextLo, fontSize = 12.sp)
                    }
                    Switch(checked = s.gestureDelay, onCheckedChange = vm::setGestureDelay, colors = glassSwitchColors())
                }
            }
        }
        item {
            Section("Tap & hold", "Screen: ${s.screenW} × ${s.screenH} px") {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    NumberField("X", x, { x = it }, Modifier.weight(1f))
                    NumberField("Y", y, { y = it }, Modifier.weight(1f))
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    SoftButton("Tap", Modifier.weight(1f), Icons.Rounded.TouchApp) { coords()?.let { vm.run(Command.TapAt(it.first, it.second)) } }
                    SoftButton("Long press", Modifier.weight(1f), Icons.Rounded.PanTool) { coords()?.let { vm.run(Command.LongPressAt(it.first, it.second)) } }
                }
                Spacer(Modifier.height(14.dp))
                OutlinedTextField(
                    value = label, onValueChange = { label = it }, singleLine = true,
                    label = { Text("Tap item by its label") }, modifier = Modifier.fillMaxWidth(),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp), colors = glassFieldColors()
                )
                Spacer(Modifier.height(10.dp))
                SoftButton("Tap label", Modifier.fillMaxWidth(), Icons.Rounded.TouchApp) {
                    if (label.isBlank()) vm.post(ActionResult.Failure("Type the label of the item to tap.")) else vm.run(Command.TapText(label.trim()))
                }
            }
        }
        item { SequenceCard(s, vm, x, y) }
    }
}

@Composable
private fun NumberField(label: String, value: String, onChange: (String) -> Unit, modifier: Modifier) {
    OutlinedTextField(
        value = value, onValueChange = { onChange(it.filter(Char::isDigit).take(5)) }, singleLine = true,
        label = { Text(label) }, modifier = modifier,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp), colors = glassFieldColors()
    )
}

@Composable
private fun SequenceCard(s: UiState, vm: MainViewModel, x: String, y: String) {
    fun addPoint(type: StepType) {
        val px = x.toIntOrNull()
        val py = y.toIntOrNull()
        if (px == null || py == null) vm.post(ActionResult.Failure("Enter X and Y above first."))
        else vm.addStep(Step(type, px, py))
    }

    Section("Automation sequence", "Runs in order, stops at the first step Android rejects") {
        if (s.steps.isEmpty()) Text("No steps yet. Add some below.", color = TextLo, fontSize = 13.sp)
        s.steps.forEachIndexed { i, step ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("${i + 1}", color = Cyan, fontSize = 13.sp, modifier = Modifier.width(24.dp))
                Text(step.describe(), color = TextHi, fontSize = 14.sp, modifier = Modifier.weight(1f))
                IconButton(onClick = { vm.removeStep(i) }) { Icon(Icons.Rounded.Close, "Remove step", tint = TextLo) }
            }
        }
        Spacer(Modifier.height(10.dp))
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            GlassChip("Tap at X, Y") { addPoint(StepType.TAP) }
            GlassChip("Long press at X, Y") { addPoint(StepType.LONG_PRESS) }
            listOf(
                StepType.SCROLL_UP, StepType.SCROLL_DOWN, StepType.SWIPE_LEFT, StepType.SWIPE_RIGHT,
                StepType.BACK, StepType.HOME, StepType.RECENTS
            ).forEach { t -> GlassChip(t.label) { vm.addStep(Step(t)) } }
            GlassChip("Wait 1 s") { vm.addStep(Step(StepType.WAIT, waitMs = 1000)) }
        }
        Spacer(Modifier.height(14.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Repeat", color = TextLo, fontSize = 13.sp, modifier = Modifier.weight(1f))
            IconButton(onClick = { vm.setRepeat(s.repeat - 1) }) { Icon(Icons.Rounded.Remove, "Fewer repeats", tint = Cyan) }
            Text("${s.repeat}×", color = TextHi, fontSize = 15.sp, modifier = Modifier.width(44.dp), textAlign = TextAlign.Center)
            IconButton(onClick = { vm.setRepeat(s.repeat + 1) }) { Icon(Icons.Rounded.Add, "More repeats", tint = Cyan) }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Pause between steps", color = TextLo, fontSize = 13.sp, modifier = Modifier.weight(1f))
            IconButton(onClick = { vm.setGap(s.gapMs - 250) }) { Icon(Icons.Rounded.Remove, "Shorter pause", tint = Cyan) }
            Text("${s.gapMs / 1000.0} s", color = TextHi, fontSize = 15.sp, modifier = Modifier.width(56.dp), textAlign = TextAlign.Center)
            IconButton(onClick = { vm.setGap(s.gapMs + 250) }) { Icon(Icons.Rounded.Add, "Longer pause", tint = Cyan) }
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            SoftButton("Run", Modifier.weight(1f), Icons.Rounded.PlayArrow, enabled = !s.running && s.steps.isNotEmpty()) { vm.runSequence() }
            SoftButton("Clear", Modifier.weight(1f), Icons.Rounded.Delete, color = TextLo, enabled = s.steps.isNotEmpty() && !s.running) { vm.clearSteps() }
        }
        if (s.running) {
            Spacer(Modifier.height(10.dp))
            Text(s.progress, color = Cyan, fontSize = 13.sp)
        }
        Spacer(Modifier.height(8.dp))
        Text(
            "Emergency stop from any app: hold Volume Up + Volume Down (needs the accessibility service).",
            color = TextLo, fontSize = 12.sp
        )
    }
}

// ═════════════════════════════════ DEVICE ═════════════════════════════════

@Composable
fun DeviceTab(s: UiState) {
    LazyColumn(contentPadding = pagePadding, verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Section("Battery") {
                val b = s.battery
                if (b == null) {
                    Text("Battery information isn't available.", color = TextLo)
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            if (b.charging) Icons.Rounded.BatteryChargingFull else Icons.Rounded.BatteryFull, null,
                            tint = if (b.charging) Ok else Cyan, modifier = Modifier.size(34.dp)
                        )
                        Spacer(Modifier.width(10.dp))
                        Text("${b.percent}%", color = TextHi, fontSize = 38.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        StatusChip(b.statusLabel, if (b.charging) Ok else TextLo)
                    }
                    Spacer(Modifier.height(10.dp))
                    GlowBar(b.percent / 100f)
                    Spacer(Modifier.height(8.dp))
                    InfoRow("Power source", b.source ?: "Battery")
                    InfoRow("Temperature", b.temperatureC?.let { "%.1f °C".format(it) } ?: "Not reported")
                    InfoRow("Health", b.healthLabel)
                }
            }
        }
        item {
            Section("Storage") {
                val st = s.storage
                if (st == null) Text("Storage information isn't available.", color = TextLo) else {
                    GlowBar(st.usedFraction)
                    Spacer(Modifier.height(8.dp))
                    InfoRow("Total", st.totalBytes.gb())
                    InfoRow("Used", st.usedBytes.gb())
                    InfoRow("Available", st.freeBytes.gb())
                }
            }
        }
        item {
            Section("Network") {
                val n = s.network
                if (n == null) Text("Network information isn't available.", color = TextLo) else {
                    StatusChip(
                        if (!n.connected) "Offline" else if (n.internetVerified) "Online" else "Connected, not verified",
                        if (!n.connected) Danger else if (n.internetVerified) Ok else Warn
                    )
                    Spacer(Modifier.height(8.dp))
                    InfoRow("Connection", if (n.connected) n.transport else "None")
                    InfoRow("Wi-Fi radio", if (n.wifiEnabled) "On" else "Off")
                    InfoRow("Mobile network", if (n.cellularActive) "Active connection" else "Not in use")
                    if (n.cellularActive) InfoRow("Network type", n.cellularGeneration ?: "Needs phone permission")
                    InfoRow("Metered", if (n.metered) "Yes" else "No")
                }
            }
        }
        item {
            Section("Device") {
                val d = s.device
                if (d == null) Text("Device information isn't available.", color = TextLo) else {
                    InfoRow("Brand", d.brand)
                    InfoRow("Model", d.model)
                    InfoRow("Android", "${d.androidVersion} (API ${d.sdk})")
                    d.securityPatch?.let { InfoRow("Security patch", it) }
                    InfoRow("RAM total", d.totalRamBytes.gb())
                    InfoRow("RAM available", d.availRamBytes.gb())
                    Spacer(Modifier.height(6.dp))
                    GlowBar(d.ramUsedFraction)
                }
            }
        }
    }
}

// ═════════════════════════════════ ACCESS ═════════════════════════════════

@Composable
fun AccessTab(s: UiState, vm: MainViewModel) {
    LazyColumn(contentPadding = pagePadding, verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Section("Permissions", "Requested only when a feature needs them") {
                PermissionRow(PermissionKind.ACCESSIBILITY, s.perms.accessibility, vm)
                PermissionRow(PermissionKind.WRITE_SETTINGS, s.perms.writeSettings, vm)
                PermissionRow(PermissionKind.DND_ACCESS, s.perms.dndAccess, vm)
                Spacer(Modifier.height(6.dp))
                Text(
                    "Flashlight, battery, storage, network and device info need no permission. " +
                        "If Android greys out the accessibility switch for a sideloaded build, open App info → ⋮ → Allow restricted settings.",
                    color = TextLo, fontSize = 12.sp
                )
            }
        }
        item {
            Section("Feature controls", "Turn individual features off. Commands for them will be refused") {
                Feature.entries.forEach { f ->
                    Row(Modifier.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(f.label, color = TextHi, fontSize = 15.sp)
                            Text(f.hint, color = TextLo, fontSize = 12.sp)
                        }
                        Switch(checked = s.toggles[f] != false, onCheckedChange = { vm.setFeature(f, it) }, colors = glassSwitchColors())
                    }
                }
            }
        }
        item {
            Section("Privacy") {
                Text(
                    "The accessibility service only acts on commands you trigger. Screen content is never stored or sent anywhere, " +
                        "and Android blocks gestures on secure screens such as passwords and payments. " +
                        "Hold Volume Up + Volume Down at any time to stop an automation.",
                    color = TextLo, fontSize = 13.sp
                )
            }
        }
    }
}

@Composable
private fun PermissionRow(kind: PermissionKind, granted: Boolean, vm: MainViewModel) {
    Row(Modifier.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(kind.title, color = TextHi, fontSize = 15.sp)
            Text(kind.why, color = TextLo, fontSize = 12.sp)
        }
        Spacer(Modifier.width(8.dp))
        if (granted) StatusChip("Granted", Ok)
        else SoftButton("Grant", color = Warn) { vm.grant(kind) }
    }
}
