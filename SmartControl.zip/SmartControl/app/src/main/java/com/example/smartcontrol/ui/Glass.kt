package com.example.smartcontrol.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val Ink = Color(0xFF070A14)
val Cyan = Color(0xFF5CE1E6)
val Violet = Color(0xFF9B87FF)
val Ok = Color(0xFF4ADE80)
val Warn = Color(0xFFFBBF24)
val Danger = Color(0xFFFF5C7A)
val TextHi = Color(0xFFEAF0FF)
val TextLo = Color(0xFF9AA6C4)

@Composable
fun SmartTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Cyan, secondary = Violet, background = Ink, surface = Ink,
            onSurface = TextHi, onBackground = TextHi, error = Danger
        ),
        content = content
    )
}

/** Slowly drifting colour glows behind everything. This is the one ambient motion in the app. */
@Composable
fun AuroraBackground(content: @Composable BoxScope.() -> Unit) {
    val transition = rememberInfiniteTransition(label = "aurora")
    val drift by transition.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(16000, easing = LinearEasing), RepeatMode.Reverse),
        label = "drift"
    )
    Box(
        Modifier
            .fillMaxSize()
            .background(Ink)
            .drawBehind {
                val w = size.width
                val h = size.height
                drawRect(
                    Brush.radialGradient(
                        listOf(Cyan.copy(alpha = 0.26f), Color.Transparent),
                        center = Offset(w * (0.1f + 0.35f * drift), h * 0.10f), radius = w * 0.95f
                    )
                )
                drawRect(
                    Brush.radialGradient(
                        listOf(Violet.copy(alpha = 0.24f), Color.Transparent),
                        center = Offset(w * (0.95f - 0.35f * drift), h * 0.72f), radius = w * 1.0f
                    )
                )
            },
        content = content
    )
}

/** Frosted-glass surface: translucent gradient fill plus a light-catching edge. */
@Composable
fun GlassCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(26.dp)
    Column(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Color.White.copy(0.11f), Color.White.copy(0.04f))))
            .border(
                BorderStroke(
                    1.dp,
                    Brush.linearGradient(listOf(Color.White.copy(0.36f), Color.White.copy(0.04f), Color.White.copy(0.16f)))
                ),
                shape
            )
            .padding(16.dp),
        content = content
    )
}

@Composable
fun Section(title: String, subtitle: String? = null, content: @Composable ColumnScope.() -> Unit) {
    GlassCard {
        Text(title, color = TextHi, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
        subtitle?.let { Text(it, color = TextLo, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp)) }
        Spacer(Modifier.height(12.dp))
        content()
    }
}

@Composable
fun ActionTile(
    icon: ImageVector,
    label: String,
    modifier: Modifier = Modifier,
    note: String? = null,
    onClick: () -> Unit
) {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val scale by animateFloatAsState(
        if (pressed) 0.93f else 1f,
        spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "press"
    )
    val dim = note != null
    val shape = RoundedCornerShape(20.dp)
    Column(
        modifier
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(shape)
            .background(Color.White.copy(if (dim) 0.03f else 0.07f))
            .border(1.dp, Color.White.copy(0.12f), shape)
            .clickable(interactionSource = source, indication = null, onClick = onClick)
            .padding(vertical = 14.dp, horizontal = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, null, tint = if (dim) TextLo else Cyan, modifier = Modifier.size(26.dp))
        Spacer(Modifier.height(6.dp))
        Text(label, color = if (dim) TextLo else TextHi, fontSize = 12.sp, textAlign = TextAlign.Center, maxLines = 2)
        note?.let { Text(it, color = Warn, fontSize = 10.sp, textAlign = TextAlign.Center) }
    }
}

@Composable
fun SoftButton(
    text: String,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    color: Color = Cyan,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    androidx.compose.material3.Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = color.copy(0.16f), contentColor = color,
            disabledContainerColor = Color.White.copy(0.05f), disabledContentColor = TextLo
        ),
        border = BorderStroke(1.dp, color.copy(if (enabled) 0.45f else 0.1f))
    ) {
        icon?.let { Icon(it, null, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)) }
        Text(text, fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

@Composable
fun GlassChip(text: String, icon: ImageVector? = null, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Row(
        Modifier
            .clip(shape)
            .background(Color.White.copy(0.07f))
            .border(1.dp, Color.White.copy(0.14f), shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        icon?.let { Icon(it, null, tint = Cyan, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(6.dp)) }
        Text(text, color = TextHi, fontSize = 13.sp)
    }
}

@Composable
fun StatusChip(text: String, color: Color) {
    val shape = RoundedCornerShape(50)
    Row(
        Modifier
            .clip(shape)
            .background(color.copy(0.14f))
            .border(1.dp, color.copy(0.4f), shape)
            .padding(horizontal = 10.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(6.dp).clip(CircleShape).background(color))
        Spacer(Modifier.width(6.dp))
        Text(text, color = color, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun GlowBar(fraction: Float, modifier: Modifier = Modifier) {
    val f by animateFloatAsState(fraction.coerceIn(0f, 1f), tween(700), label = "bar")
    Box(
        modifier
            .fillMaxWidth()
            .height(10.dp)
            .clip(RoundedCornerShape(5.dp))
            .background(Color.White.copy(0.1f))
    ) {
        Box(
            Modifier
                .fillMaxWidth(f)
                .fillMaxHeight()
                .background(Brush.horizontalGradient(listOf(Cyan, Violet)))
        )
    }
}

@Composable
fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = TextLo, fontSize = 14.sp)
        Text(value, color = TextHi, fontSize = 14.sp, textAlign = TextAlign.End, modifier = Modifier.padding(start = 16.dp))
    }
}

@Composable
fun PermissionHint(text: String, action: String, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Warn.copy(0.10f))
            .border(1.dp, Warn.copy(0.35f), shape)
            .padding(start = 12.dp, top = 4.dp, bottom = 4.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text, color = Warn, fontSize = 13.sp, modifier = Modifier.weight(1f))
        TextButton(onClick = onClick) { Text(action, color = Warn, fontWeight = FontWeight.SemiBold) }
    }
}

@Composable
fun glassFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = Cyan,
    unfocusedBorderColor = Color.White.copy(0.2f),
    focusedTextColor = TextHi,
    unfocusedTextColor = TextHi,
    cursorColor = Cyan,
    focusedContainerColor = Color.White.copy(0.06f),
    unfocusedContainerColor = Color.White.copy(0.05f),
    focusedPlaceholderColor = TextLo,
    unfocusedPlaceholderColor = TextLo,
    focusedLabelColor = Cyan,
    unfocusedLabelColor = TextLo
)

@Composable
fun glassSliderColors() = SliderDefaults.colors(
    thumbColor = Cyan,
    activeTrackColor = Cyan,
    inactiveTrackColor = Color.White.copy(0.15f),
    disabledThumbColor = TextLo,
    disabledActiveTrackColor = TextLo,
    disabledInactiveTrackColor = Color.White.copy(0.08f)
)

@Composable
fun glassSwitchColors() = SwitchDefaults.colors(
    checkedThumbColor = Ink,
    checkedTrackColor = Cyan,
    uncheckedThumbColor = TextLo,
    uncheckedTrackColor = Color.White.copy(0.08f),
    uncheckedBorderColor = Color.White.copy(0.2f)
)
