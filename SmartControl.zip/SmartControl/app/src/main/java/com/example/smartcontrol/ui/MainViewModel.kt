package com.example.smartcontrol.ui

import android.app.Application
import android.content.ActivityNotFoundException
import android.content.Intent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.smartcontrol.command.Command
import com.example.smartcontrol.command.CommandExecutor
import com.example.smartcontrol.command.CommandParser
import com.example.smartcontrol.command.feature
import com.example.smartcontrol.control.AutomationEngine
import com.example.smartcontrol.control.DeviceController
import com.example.smartcontrol.control.EmergencyStop
import com.example.smartcontrol.control.Prefs
import com.example.smartcontrol.control.ScreenAutomationService
import com.example.smartcontrol.model.ActionResult
import com.example.smartcontrol.model.ActionResult.Failure
import com.example.smartcontrol.model.ActionResult.Success
import com.example.smartcontrol.model.BatteryInfo
import com.example.smartcontrol.model.DeviceInfo
import com.example.smartcontrol.model.Feature
import com.example.smartcontrol.model.LaunchableApp
import com.example.smartcontrol.model.NetSnapshot
import com.example.smartcontrol.model.PermissionKind
import com.example.smartcontrol.model.SettingsTarget
import com.example.smartcontrol.model.Step
import com.example.smartcontrol.model.StorageInfo
import com.example.smartcontrol.model.StreamKind
import com.example.smartcontrol.model.VolumeState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class Permissions(
    val accessibility: Boolean = false,
    val writeSettings: Boolean = false,
    val dndAccess: Boolean = false
)

data class UiState(
    val battery: BatteryInfo? = null,
    val storage: StorageInfo? = null,
    val network: NetSnapshot? = null,
    val device: DeviceInfo? = null,
    val torchOn: Boolean = false,
    val hasFlash: Boolean = true,
    val volumes: Map<StreamKind, VolumeState> = emptyMap(),
    val brightness: Int? = null,
    val perms: Permissions = Permissions(),
    val toggles: Map<Feature, Boolean> = Feature.entries.associateWith { true },
    val result: ActionResult? = null,
    val heard: String? = null,
    val running: Boolean = false,
    val progress: String = "",
    val steps: List<Step> = emptyList(),
    val repeat: Int = 1,
    val gapMs: Long = 800,
    val gestureDelay: Boolean = true,
    val screenW: Int = 0,
    val screenH: Int = 0,
    val apps: List<LaunchableApp> = emptyList()
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val device = DeviceController(application)
    private val prefs = Prefs(application)
    private val engine = AutomationEngine(viewModelScope)

    private val _state = MutableStateFlow(
        UiState(
            toggles = Feature.entries.associateWith { prefs.isEnabled(it) },
            steps = prefs.loadSteps(),
            hasFlash = device.hasFlash
        )
    )
    val state: StateFlow<UiState> = _state.asStateFlow()

    private val executor = CommandExecutor(device, engine) { _state.value.toggles }
    private var messageJob: Job? = null
    private var commandJob: Job? = null

    init {
        EmergencyStop.handler = { viewModelScope.launch { stopAll() } }
        viewModelScope.launch { device.torchOn.collect { on -> _state.update { it.copy(torchOn = on) } } }
        viewModelScope.launch { engine.running.collect { r -> _state.update { it.copy(running = r) } } }
        viewModelScope.launch { engine.progress.collect { p -> _state.update { it.copy(progress = p) } } }
        val dm = application.resources.displayMetrics
        _state.update { it.copy(screenW = dm.widthPixels, screenH = dm.heightPixels) }
        loadApps()
        refresh()
    }

    /** Re-reads every live value from Android. Called every ~2 s while the app is visible. */
    fun refresh() {
        val volumes = StreamKind.entries.associateWith { device.volume(it) }
        _state.update {
            it.copy(
                battery = device.battery(),
                storage = device.storage(),
                network = device.network(),
                device = device.deviceInfo(),
                volumes = volumes,
                brightness = device.brightnessPercent(),
                perms = Permissions(
                    accessibility = ScreenAutomationService.instance != null,
                    writeSettings = device.canWriteSettings(),
                    dndAccess = device.hasDndAccess()
                )
            )
        }
    }

    fun loadApps() {
        viewModelScope.launch(Dispatchers.Default) {
            val apps = device.launchableApps()
            _state.update { it.copy(apps = apps) }
        }
    }

    // ───────────── Commands ─────────────

    fun submit(text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        _state.update { it.copy(heard = t) }
        run(CommandParser.parse(t))
    }

    fun run(c: Command) {
        commandJob = viewModelScope.launch {
            if (c.feature == Feature.GESTURES && _state.value.gestureDelay &&
                _state.value.toggles[Feature.GESTURES] != false &&
                ScreenAutomationService.instance != null
            ) {
                post(Success("Running in 3 s. Switch to the target app now."))
                delay(3000)
            }
            post(executor.execute(c))
        }
    }

    fun stopAll() {
        commandJob?.cancel()
        val wasRunning = engine.stop()
        post(Success(if (wasRunning) "Automation stopped." else "Nothing is running. All automation is idle."))
    }

    fun post(r: ActionResult) {
        _state.update { it.copy(result = r) }
        refresh()
        messageJob?.cancel()
        messageJob = viewModelScope.launch {
            delay(6000)
            _state.update { it.copy(result = null) }
        }
    }

    fun dismissResult() = _state.update { it.copy(result = null) }

    // ───────────── Direct controls ─────────────

    fun setFlashlight(on: Boolean) = post(device.setFlashlight(on))
    fun setVolume(k: StreamKind, percent: Int) = post(device.setVolume(k, percent))
    fun toggleMute(k: StreamKind) = post(device.setMuted(k, !(_state.value.volumes[k]?.muted ?: false)))
    fun setBrightness(percent: Int) {
        if (_state.value.toggles[Feature.BRIGHTNESS] == false) {
            return post(Failure("Brightness is turned off. Switch it on in the Access tab."))
        }
        post(device.setBrightnessPercent(percent))
    }
    fun openPackage(app: LaunchableApp) = post(device.launchPackage(app))
    fun openSettings(t: SettingsTarget) = run(Command.OpenSettings(t))

    fun grant(kind: PermissionKind) {
        try {
            getApplication<Application>().startActivity(
                device.permissionIntent(kind).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: ActivityNotFoundException) {
            post(Failure("This device has no settings screen for ${kind.title}."))
        }
    }

    fun setFeature(f: Feature, enabled: Boolean) {
        prefs.setEnabled(f, enabled)
        _state.update { it.copy(toggles = it.toggles + (f to enabled)) }
    }

    // ───────────── Sequence builder ─────────────

    fun addStep(step: Step) = updateSteps { it + step }
    fun removeStep(index: Int) = updateSteps { l -> l.filterIndexed { i, _ -> i != index } }
    fun clearSteps() = updateSteps { emptyList() }

    private fun updateSteps(change: (List<Step>) -> List<Step>) {
        _state.update { it.copy(steps = change(it.steps)) }
        prefs.saveSteps(_state.value.steps)
    }

    fun setRepeat(n: Int) = _state.update { it.copy(repeat = n.coerceIn(1, AutomationEngine.MAX_REPEAT)) }
    fun setGap(ms: Long) = _state.update { it.copy(gapMs = ms.coerceIn(AutomationEngine.MIN_GAP_MS, 10_000)) }
    fun setGestureDelay(on: Boolean) = _state.update { it.copy(gestureDelay = on) }

    fun runSequence() {
        if (_state.value.toggles[Feature.GESTURES] == false) {
            return post(Failure("Screen gestures are turned off. Switch them on in the Access tab."))
        }
        val s = _state.value
        engine.start(s.steps, s.repeat, s.gapMs) { post(it) }
    }

    override fun onCleared() {
        EmergencyStop.handler = null
        engine.stop()
        device.release()
    }
}
