package com.example.smartcontrol.command

import android.accessibilityservice.AccessibilityService
import com.example.smartcontrol.control.AutomationEngine
import com.example.smartcontrol.control.DeviceController
import com.example.smartcontrol.control.ScreenAutomationService
import com.example.smartcontrol.model.ActionResult
import com.example.smartcontrol.model.ActionResult.Failure
import com.example.smartcontrol.model.ActionResult.NeedsPermission
import com.example.smartcontrol.model.ActionResult.Success
import com.example.smartcontrol.model.Feature
import com.example.smartcontrol.model.InfoTopic
import com.example.smartcontrol.model.PermissionKind
import com.example.smartcontrol.model.StreamKind
import com.example.smartcontrol.model.summary
import kotlinx.coroutines.delay

class CommandExecutor(
    private val device: DeviceController,
    private val engine: AutomationEngine,
    private val enabled: () -> Map<Feature, Boolean>
) {
    private val needsAccessibility = NeedsPermission(
        "Turn on the accessibility service to use this action.",
        PermissionKind.ACCESSIBILITY
    )

    suspend fun execute(c: Command): ActionResult {
        c.feature?.let { f ->
            if (enabled()[f] == false) {
                return Failure("${f.label} is turned off. Switch it on in the Access tab.")
            }
        }
        return when (c) {
            is Command.OpenApp -> device.openApp(c.name)

            Command.Home -> global(AccessibilityService.GLOBAL_ACTION_HOME, "Went to the home screen.")
            Command.Back -> global(AccessibilityService.GLOBAL_ACTION_BACK, "Went back.")
            Command.Recents -> global(AccessibilityService.GLOBAL_ACTION_RECENTS, "Opened recent apps.")
            Command.QuickSettingsPanel ->
                global(AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS, "Opened Quick Settings.")
            Command.Notifications ->
                global(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS, "Opened the notification panel.")
            Command.SwitchApp -> switchToPreviousApp()

            is Command.Flashlight -> device.setFlashlight(c.on)

            is Command.VolumeStep -> device.stepVolume(StreamKind.MEDIA, c.up)
            is Command.VolumeSet -> device.setVolume(StreamKind.MEDIA, c.percent)
            is Command.Mute -> device.setMuted(StreamKind.MEDIA, c.mute)

            is Command.BrightnessSet -> device.setBrightnessPercent(c.percent)
            is Command.BrightnessStep -> {
                val current = device.brightnessPercent()
                    ?: return Failure("Brightness isn't readable on this device.")
                device.setBrightnessPercent(current + if (c.up) 10 else -10)
            }

            is Command.Scroll -> gesture("Scrolled ${if (c.down) "down" else "up"}.") { it.scroll(c.down) }
            is Command.Swipe -> gesture("Swiped ${if (c.left) "left" else "right"}.") { it.swipeHorizontal(c.left) }
            is Command.TapAt -> withinScreen(c.x, c.y) { svc ->
                gesture("Tapped (${c.x}, ${c.y}).") { svc.tap(c.x.toFloat(), c.y.toFloat()) }
            }
            is Command.LongPressAt -> withinScreen(c.x, c.y) { svc ->
                gesture("Long-pressed (${c.x}, ${c.y}).") { svc.longPress(c.x.toFloat(), c.y.toFloat()) }
            }
            is Command.TapText -> {
                val svc = ScreenAutomationService.instance ?: return needsAccessibility
                if (svc.clickByLabel(c.label)) Success("Tapped “${c.label}”.")
                else Failure("Couldn't find a tappable item labelled “${c.label}” on this screen.")
            }

            is Command.OpenSettings -> device.openSettings(c.target)

            is Command.Show -> when (c.topic) {
                InfoTopic.BATTERY -> device.battery()?.let { Success(it.summary()) }
                    ?: Failure("Battery information isn't available.")
                InfoTopic.STORAGE -> Success(device.storage().summary())
                InfoTopic.NETWORK -> Success(device.network().summary())
                InfoTopic.DEVICE -> Success(device.deviceInfo().summary())
            }

            Command.CheckInternet -> checkInternet()

            Command.StopAutomation ->
                Success(if (engine.stop()) "Automation stopped." else "Nothing was running.")

            is Command.Unknown ->
                Failure("I didn't understand “${c.text}”. Try “open YouTube”, “turn on flashlight” or “set brightness to 50%”.")
        }
    }

    private fun global(action: Int, ok: String): ActionResult {
        val svc = ScreenAutomationService.instance ?: return needsAccessibility
        return if (svc.global(action)) Success(ok) else Failure("Android rejected that action.")
    }

    /** Double-tap on Recents toggles to the previous app on many launchers. Behaviour varies by device. */
    private suspend fun switchToPreviousApp(): ActionResult {
        val svc = ScreenAutomationService.instance ?: return needsAccessibility
        if (!svc.global(AccessibilityService.GLOBAL_ACTION_RECENTS)) return Failure("Android rejected that action.")
        delay(350)
        return if (svc.global(AccessibilityService.GLOBAL_ACTION_RECENTS))
            Success("Sent the app-switch shortcut. The result depends on your launcher.")
        else Failure("Android rejected the second Recents press.")
    }

    private suspend fun gesture(ok: String, block: suspend (ScreenAutomationService) -> Boolean): ActionResult {
        val svc = ScreenAutomationService.instance ?: return needsAccessibility
        return if (block(svc)) Success(ok)
        else Failure("Android didn't complete the gesture. The screen may be protected (passwords, payments) or another gesture was in progress.")
    }

    private suspend fun withinScreen(
        x: Int, y: Int, block: suspend (ScreenAutomationService) -> ActionResult
    ): ActionResult {
        val svc = ScreenAutomationService.instance ?: return needsAccessibility
        val (w, h) = svc.screenSize()
        return if (x in 0 until w && y in 0 until h) block(svc)
        else Failure("($x, $y) is outside the screen (${w} × ${h} px).")
    }

    private fun checkInternet(): ActionResult {
        val n = device.network()
        return when {
            !n.connected -> Failure("No active connection. Wi-Fi is ${if (n.wifiEnabled) "on" else "off"}.")
            !n.internetVerified -> Failure(
                "Connected via ${n.transport}, but Android couldn't verify internet access (sign-in page or no data)."
            )
            else -> Success(
                "Online via ${n.transport}${n.cellularGeneration?.let { " ($it)" } ?: ""}. Internet verified by Android."
            )
        }
    }
}
