package com.example.smartcontrol.control

import android.annotation.SuppressLint
import android.app.ActivityManager
import android.app.NotificationManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.provider.Settings
import android.telephony.TelephonyManager
import com.example.smartcontrol.model.ActionResult
import com.example.smartcontrol.model.ActionResult.Failure
import com.example.smartcontrol.model.ActionResult.NeedsPermission
import com.example.smartcontrol.model.ActionResult.Success
import com.example.smartcontrol.model.BatteryInfo
import com.example.smartcontrol.model.DeviceInfo
import com.example.smartcontrol.model.LaunchableApp
import com.example.smartcontrol.model.NetSnapshot
import com.example.smartcontrol.model.PermissionKind
import com.example.smartcontrol.model.SettingsTarget
import com.example.smartcontrol.model.StorageInfo
import com.example.smartcontrol.model.StreamKind
import com.example.smartcontrol.model.VolumeState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.roundToInt

/** Thin wrappers over Android system services. Every value shown in the UI comes from here. */
class DeviceController(context: Context) {

    private val app = context.applicationContext
    private val camera = app.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private val audio = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val connectivity = app.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    private val wifi = app.getSystemService(Context.WIFI_SERVICE) as WifiManager
    private val telephony = app.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager
    private val notifications = app.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    private val activityManager = app.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    private val pm = app.packageManager

    // ───────────────────────── Flashlight (CameraManager) ─────────────────────────

    private val torchId: String? = runCatching {
        camera.cameraIdList.firstOrNull { id ->
            val c = camera.getCameraCharacteristics(id)
            c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
        }
    }.getOrNull()

    val hasFlash: Boolean get() = torchId != null

    private val _torchOn = MutableStateFlow(false)
    /** Live torch state, driven by the system's TorchCallback (so it also reflects changes from other apps). */
    val torchOn: StateFlow<Boolean> = _torchOn.asStateFlow()

    private val torchCallback = object : CameraManager.TorchCallback() {
        override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
            if (cameraId == torchId) _torchOn.value = enabled
        }
    }

    init {
        if (torchId != null) camera.registerTorchCallback(torchCallback, Handler(Looper.getMainLooper()))
    }

    fun release() {
        if (torchId != null) camera.unregisterTorchCallback(torchCallback)
    }

    /** [on] = null toggles. No CAMERA permission is needed for setTorchMode. */
    fun setFlashlight(on: Boolean?): ActionResult {
        val id = torchId ?: return Failure("This device has no camera flash.")
        val target = on ?: !_torchOn.value
        return try {
            camera.setTorchMode(id, target)
            Success("Flashlight ${if (target) "on" else "off"}.")
        } catch (e: CameraAccessException) {
            Failure("The camera is in use by another app, so the flashlight is unavailable.")
        } catch (e: IllegalArgumentException) {
            Failure("The flashlight can't be controlled right now.")
        }
    }

    // ───────────────────────── Volume (AudioManager) ─────────────────────────

    private fun maxVolume(k: StreamKind) = audio.getStreamMaxVolume(k.id).coerceAtLeast(1)

    fun volume(k: StreamKind) = VolumeState(
        percent = audio.getStreamVolume(k.id) * 100 / maxVolume(k),
        muted = audio.isStreamMute(k.id)
    )

    fun stepVolume(k: StreamKind, up: Boolean): ActionResult = guardAudio {
        audio.adjustStreamVolume(
            k.id,
            if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
            AudioManager.FLAG_SHOW_UI
        )
        "${k.label} volume ${volume(k).percent}%."
    }

    fun setVolume(k: StreamKind, percent: Int): ActionResult = guardAudio {
        val index = (percent.coerceIn(0, 100) / 100f * maxVolume(k)).roundToInt()
        audio.setStreamVolume(k.id, index, AudioManager.FLAG_SHOW_UI)
        "${k.label} volume ${volume(k).percent}%."
    }

    fun setMuted(k: StreamKind, mute: Boolean): ActionResult = guardAudio {
        audio.adjustStreamVolume(
            k.id,
            if (mute) AudioManager.ADJUST_MUTE else AudioManager.ADJUST_UNMUTE,
            AudioManager.FLAG_SHOW_UI
        )
        "${k.label} ${if (audio.isStreamMute(k.id)) "muted" else "unmuted"}."
    }

    private inline fun guardAudio(block: () -> String): ActionResult = try {
        Success(block())
    } catch (e: SecurityException) {
        NeedsPermission(
            "Android requires Do Not Disturb access to change this volume.",
            PermissionKind.DND_ACCESS
        )
    }

    // ───────────────────────── Brightness (Settings.System) ─────────────────────────

    fun canWriteSettings(): Boolean = Settings.System.canWrite(app)

    fun brightnessPercent(): Int? = try {
        (Settings.System.getInt(app.contentResolver, Settings.System.SCREEN_BRIGHTNESS) * 100f / 255f)
            .roundToInt().coerceIn(0, 100)
    } catch (e: Settings.SettingNotFoundException) {
        null
    }

    fun setBrightnessPercent(percent: Int): ActionResult {
        if (!canWriteSettings()) {
            return NeedsPermission(
                "Allow “Modify system settings” to change brightness.",
                PermissionKind.WRITE_SETTINGS
            )
        }
        val value = (percent.coerceIn(1, 100) * 255 / 100).coerceAtLeast(1)
        return try {
            Settings.System.putInt(
                app.contentResolver,
                Settings.System.SCREEN_BRIGHTNESS_MODE,
                Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
            )
            Settings.System.putInt(app.contentResolver, Settings.System.SCREEN_BRIGHTNESS, value)
            Success("Brightness ${brightnessPercent() ?: percent}%. Adaptive brightness switched off.")
        } catch (e: SecurityException) {
            NeedsPermission("Brightness change was blocked by Android.", PermissionKind.WRITE_SETTINGS)
        }
    }

    // ───────────────────────── Battery / storage / network / device ─────────────────────────

    fun battery(): BatteryInfo? {
        val i = app.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return null
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        if (level < 0 || scale <= 0) return null
        val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL
        val temp = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
        return BatteryInfo(
            percent = level * 100 / scale,
            charging = charging,
            statusLabel = when (status) {
                BatteryManager.BATTERY_STATUS_CHARGING -> "Charging"
                BatteryManager.BATTERY_STATUS_DISCHARGING -> "Discharging"
                BatteryManager.BATTERY_STATUS_FULL -> "Full"
                BatteryManager.BATTERY_STATUS_NOT_CHARGING -> "Not charging"
                else -> "Unknown"
            },
            source = when (i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)) {
                BatteryManager.BATTERY_PLUGGED_AC -> "AC charger"
                BatteryManager.BATTERY_PLUGGED_USB -> "USB"
                BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Wireless"
                else -> null
            },
            temperatureC = if (temp == Int.MIN_VALUE) null else temp / 10f,
            healthLabel = when (i.getIntExtra(BatteryManager.EXTRA_HEALTH, -1)) {
                BatteryManager.BATTERY_HEALTH_GOOD -> "Good"
                BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Overheating"
                BatteryManager.BATTERY_HEALTH_DEAD -> "Dead"
                BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Over voltage"
                BatteryManager.BATTERY_HEALTH_COLD -> "Cold"
                BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE -> "Failure"
                else -> "Unknown"
            }
        )
    }

    /** Measures the user data partition, which is what Android's own Storage screen reports as used/free. */
    fun storage(): StorageInfo {
        val st = StatFs(Environment.getDataDirectory().path)
        val total = st.totalBytes
        val free = st.availableBytes
        return StorageInfo(total, total - free, free)
    }

    @SuppressLint("MissingPermission")
    fun network(): NetSnapshot {
        val caps = connectivity.activeNetwork?.let { connectivity.getNetworkCapabilities(it) }
        val cellular = caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true
        val generation = if (cellular) {
            // Needs READ_PHONE_STATE on API 30+. We don't request it; it simply stays "unavailable".
            runCatching { generation(telephony!!.dataNetworkType) }.getOrNull()
        } else null
        return NetSnapshot(
            connected = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true,
            internetVerified = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true,
            transport = when {
                caps == null -> "None"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
                cellular -> "Mobile data"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> "VPN"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_BLUETOOTH) -> "Bluetooth"
                else -> "Other"
            },
            wifiEnabled = wifi.isWifiEnabled,
            cellularActive = cellular,
            cellularGeneration = generation,
            metered = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED) == false
        )
    }

    private fun generation(type: Int): String = when (type) {
        TelephonyManager.NETWORK_TYPE_NR -> "5G"
        TelephonyManager.NETWORK_TYPE_LTE -> "4G LTE"
        TelephonyManager.NETWORK_TYPE_UMTS, TelephonyManager.NETWORK_TYPE_HSDPA,
        TelephonyManager.NETWORK_TYPE_HSUPA, TelephonyManager.NETWORK_TYPE_HSPA,
        TelephonyManager.NETWORK_TYPE_HSPAP, TelephonyManager.NETWORK_TYPE_EVDO_0,
        TelephonyManager.NETWORK_TYPE_EVDO_A, TelephonyManager.NETWORK_TYPE_EVDO_B,
        TelephonyManager.NETWORK_TYPE_EHRPD -> "3G"
        TelephonyManager.NETWORK_TYPE_GPRS, TelephonyManager.NETWORK_TYPE_EDGE,
        TelephonyManager.NETWORK_TYPE_CDMA, TelephonyManager.NETWORK_TYPE_1xRTT,
        TelephonyManager.NETWORK_TYPE_IDEN -> "2G"
        else -> "Unknown"
    }

    fun deviceInfo(): DeviceInfo {
        val mem = ActivityManager.MemoryInfo().also { activityManager.getMemoryInfo(it) }
        return DeviceInfo(
            brand = Build.BRAND.replaceFirstChar { it.uppercase() },
            model = Build.MODEL,
            androidVersion = Build.VERSION.RELEASE,
            sdk = Build.VERSION.SDK_INT,
            securityPatch = Build.VERSION.SECURITY_PATCH.takeIf { it.isNotBlank() },
            totalRamBytes = mem.totalMem,
            availRamBytes = mem.availMem
        )
    }

    // ───────────────────────── Apps ─────────────────────────

    @Suppress("DEPRECATION")
    fun launchableApps(): List<LaunchableApp> {
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(query, 0)
            .map { LaunchableApp(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase() }
    }

    fun openApp(name: String): ActionResult {
        val q = normalize(name)
        if (q.isEmpty()) return Failure("Tell me which app to open.")
        val apps = launchableApps()
        val match = apps.firstOrNull { normalize(it.label) == q }
            ?: apps.firstOrNull { normalize(it.label).startsWith(q) }
            ?: apps.firstOrNull { normalize(it.label).contains(q) }
        return match?.let { launchPackage(it) }
            ?: Failure("No installed app matches “$name”.")
    }

    fun launchPackage(appInfo: LaunchableApp): ActionResult {
        val intent = pm.getLaunchIntentForPackage(appInfo.packageName)
            ?: return Failure("${appInfo.label} can't be launched.")
        return try {
            app.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            Success("Opening ${appInfo.label}.")
        } catch (e: ActivityNotFoundException) {
            Failure("${appInfo.label} can't be launched.")
        } catch (e: SecurityException) {
            Failure("Android blocked launching ${appInfo.label}.")
        }
    }

    private fun normalize(s: String) = s.lowercase().filter { it.isLetterOrDigit() }

    // ───────────────────────── Settings shortcuts & permissions ─────────────────────────

    fun openSettings(t: SettingsTarget): ActionResult {
        val intent = when (t) {
            SettingsTarget.WIFI ->
                if (Build.VERSION.SDK_INT >= 29) Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)
                else Intent(Settings.ACTION_WIFI_SETTINGS)
            SettingsTarget.BLUETOOTH -> Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
            SettingsTarget.AIRPLANE -> Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS)
            SettingsTarget.HOTSPOT -> Intent(Settings.ACTION_WIRELESS_SETTINGS)
            SettingsTarget.DISPLAY -> Intent(Settings.ACTION_DISPLAY_SETTINGS)
            SettingsTarget.SOUND -> Intent(Settings.ACTION_SOUND_SETTINGS)
            SettingsTarget.LOCATION -> Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
            SettingsTarget.NFC -> Intent(Settings.ACTION_NFC_SETTINGS)
            SettingsTarget.BATTERY_SAVER -> Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)
            SettingsTarget.STORAGE -> Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS)
            SettingsTarget.ALL -> Intent(Settings.ACTION_SETTINGS)
        }.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

        val needsManualToggle = t in setOf(
            SettingsTarget.WIFI, SettingsTarget.BLUETOOTH, SettingsTarget.AIRPLANE,
            SettingsTarget.HOTSPOT, SettingsTarget.NFC, SettingsTarget.LOCATION
        )
        return try {
            app.startActivity(intent)
            Success(
                if (needsManualToggle)
                    "Opened ${t.label}. Android doesn't let apps flip this switch, so confirm it there."
                else "Opened ${t.label} settings."
            )
        } catch (e: ActivityNotFoundException) {
            Failure("This device has no ${t.label} settings screen.")
        }
    }

    fun permissionIntent(kind: PermissionKind): Intent = when (kind) {
        PermissionKind.ACCESSIBILITY -> Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
        PermissionKind.WRITE_SETTINGS ->
            Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${app.packageName}"))
        PermissionKind.DND_ACCESS -> Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
    }

    fun hasDndAccess(): Boolean = notifications.isNotificationPolicyAccessGranted
}
