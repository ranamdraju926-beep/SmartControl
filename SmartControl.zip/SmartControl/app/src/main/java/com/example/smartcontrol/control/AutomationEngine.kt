package com.example.smartcontrol.control

import android.accessibilityservice.AccessibilityService
import com.example.smartcontrol.model.ActionResult
import com.example.smartcontrol.model.ActionResult.Failure
import com.example.smartcontrol.model.ActionResult.NeedsPermission
import com.example.smartcontrol.model.ActionResult.Success
import com.example.smartcontrol.model.PermissionKind
import com.example.smartcontrol.model.Step
import com.example.smartcontrol.model.StepType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/** Runs a user-built sequence of gestures. Bounded, cancellable, and stops on the first rejected step. */
class AutomationEngine(private val scope: CoroutineScope) {

    companion object {
        const val MAX_REPEAT = 100
        const val MIN_GAP_MS = 250L
        const val START_DELAY_MS = 3000L
    }

    private val _running = MutableStateFlow(false)
    val running: StateFlow<Boolean> = _running.asStateFlow()

    private val _progress = MutableStateFlow("")
    val progress: StateFlow<String> = _progress.asStateFlow()

    private var job: Job? = null

    fun start(steps: List<Step>, repeat: Int, gapMs: Long, onFinished: (ActionResult) -> Unit) {
        if (_running.value) return onFinished(Failure("An automation is already running."))
        if (steps.isEmpty()) return onFinished(Failure("Add at least one step first."))
        if (ScreenAutomationService.instance == null) {
            return onFinished(
                NeedsPermission("Turn on the accessibility service to run automations.", PermissionKind.ACCESSIBILITY)
            )
        }
        val runs = repeat.coerceIn(1, MAX_REPEAT)
        val gap = gapMs.coerceAtLeast(MIN_GAP_MS)
        _running.value = true
        job = scope.launch {
            var result: ActionResult = Success("Automation finished: ${steps.size} steps × $runs.")
            try {
                _progress.value = "Starting in ${START_DELAY_MS / 1000} s. Switch to the target app now."
                delay(START_DELAY_MS)
                outer@ for (run in 1..runs) {
                    for ((i, step) in steps.withIndex()) {
                        ensureActive()
                        _progress.value = "Run $run/$runs · step ${i + 1}/${steps.size}: ${step.describe()}"
                        if (!perform(step)) {
                            result = Failure(
                                "Stopped at step ${i + 1} (${step.describe()}). Android rejected it, " +
                                    "the screen is protected, or the service disconnected."
                            )
                            break@outer
                        }
                        delay(gap)
                    }
                }
            } finally {
                _running.value = false
                _progress.value = ""
            }
            onFinished(result)
        }
    }

    /** Returns true if something was running. */
    fun stop(): Boolean {
        val wasRunning = _running.value
        job?.cancel()
        job = null
        _running.value = false
        _progress.value = ""
        return wasRunning
    }

    private suspend fun perform(s: Step): Boolean {
        val svc = ScreenAutomationService.instance ?: return false
        return when (s.type) {
            StepType.TAP -> svc.tap(s.x.toFloat(), s.y.toFloat())
            StepType.LONG_PRESS -> svc.longPress(s.x.toFloat(), s.y.toFloat())
            StepType.SCROLL_UP -> svc.scroll(down = false)
            StepType.SCROLL_DOWN -> svc.scroll(down = true)
            StepType.SWIPE_LEFT -> svc.swipeHorizontal(left = true)
            StepType.SWIPE_RIGHT -> svc.swipeHorizontal(left = false)
            StepType.BACK -> svc.global(AccessibilityService.GLOBAL_ACTION_BACK)
            StepType.HOME -> svc.global(AccessibilityService.GLOBAL_ACTION_HOME)
            StepType.RECENTS -> svc.global(AccessibilityService.GLOBAL_ACTION_RECENTS)
            StepType.WAIT -> { delay(s.waitMs.coerceIn(100, 30_000)); true }
        }
    }
}
