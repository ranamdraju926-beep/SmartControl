# Smart Control: Android module

Native Kotlin + Jetpack Compose. Open the `SmartControl` folder in Android Studio (Ladybug or newer), let Gradle sync, run on a **real device** (the emulator has no flash, and gestures behave differently).

## Structure
| Path | Role |
|---|---|
| `control/DeviceController.kt` | Flashlight (CameraManager + TorchCallback), volume (AudioManager), brightness (Settings.System), battery, storage (StatFs), network (ConnectivityManager), device/RAM, app launching, settings intents |
| `control/ScreenAutomationService.kt` | AccessibilityService: tap, long press, swipe, scroll, Back/Home/Recents/Quick Settings/Notifications, tap-by-label, Volume Up+Down emergency stop |
| `control/AutomationEngine.kt` | Bounded, cancellable gesture sequences |
| `command/` | Offline natural-language parser, executor, per-feature gating |
| `ui/` | Glassmorphism Compose UI, 4 tabs (Control, Automate, Device, Access) |

## What is real vs. restricted by Android
| Feature | Mechanism | Notes |
|---|---|---|
| Flashlight | `CameraManager.setTorchMode` | No permission. Status from `TorchCallback`. Fails if another app holds the camera. |
| Volume / mute | `AudioManager` | Ring stream may need Do Not Disturb access; the app shows a Grant button. |
| Brightness | `Settings.System` | Needs the "Modify system settings" special permission. Some OEMs use a different range or ignore the write. |
| Battery, storage, network, device, RAM | BatteryManager, StatFs, ConnectivityManager, Build, ActivityManager | Temperature is shown as "not reported" if the device omits it. Mobile generation (4G/5G) needs READ_PHONE_STATE, which is intentionally not requested. |
| Wi-Fi / Bluetooth toggles | Opens system panel/screen | Android 10+ forbids apps from flipping these. The UI says so. |
| Quick Settings panel, Back/Home/Recents | Accessibility global actions | Needs the accessibility service. |
| Tap / swipe / scroll / long press | `dispatchGesture` | Reports success only when Android calls `onCompleted`. Blocked on secure screens. |
| "Last app" | Double Recents press | Best effort; depends on launcher and navigation mode. |
| Voice | `RecognizerIntent` (system speech UI) | No microphone permission needed. |

## Safety
- Every gesture feature can be switched off individually (Access tab).
- **Stop** button in the header, plus **hold Volume Up + Volume Down** from any app.
- Sequences: max 100 repeats, min 250 ms between steps, 3 s start delay, stops at the first step Android rejects.
- Single gesture commands have an optional 3 s delay so you can switch to the target app first.

## Before publishing on Google Play
Accessibility API apps must complete Play's Accessibility declaration and disclose the use prominently in the app. The service description string in `strings.xml` is a starting point. Sideloaded builds on Android 13+ may need "Allow restricted settings" in App info.

## Not verified
This project was written without access to the Android SDK, so it has not been compiled or run. Expect to fix small import or version issues on first sync. Run `CommandParserTest` first; then check each tab on a physical device.

## Ideas for next steps
Foreground-service notification with a Stop action, a Quick Settings tile for Stop, wiring `CommandParser` to an LLM that outputs the same `Command` objects, and a launcher icon.
